
/**
 * Write a description of class Book here.
 * 
 * @author (Rana) 
 * @version (2.0)
 */
public class Book
{
    private String title;
    private int numPages;
    private String authorName;

    public Book(){
    }

    public Book(String inputTitle){
    }
  //  public Book(String author){ }
    public Book(String authorName,  boolean something){}

    public Book(String inputTitle,int inputNumPages){
    }

    public Book(int inputNumPages,String inputTitle){
    }

    public Book(String newAuthorName, double price){
    }

     public Book(String author, String title){

     }
     
     public Book(double price,String author){}
    

}
