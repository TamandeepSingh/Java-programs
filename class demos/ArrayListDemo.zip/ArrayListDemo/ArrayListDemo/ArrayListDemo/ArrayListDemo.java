/**
 * Demo ArrayList
 * @author Rana
 * @version 2019
 */
import java.util.ArrayList;
public class ArrayListDemo
{
    private ArrayList<Car> carLot;
    private ArrayList<Integer> numbers;
    /**
     * ArrayListDemo Constructor
     *
     */
    public ArrayListDemo(){
        carLot = new ArrayList<Car>();
        numbers = new ArrayList();
        // Car c = new Car("GM",2000);
        // carLot.add(c);
        // carLot.add("word");
        // Stock s = new Stock("LG",15);
        // carLot.add(s);
    }

    public void demoWrapperClass(){
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        for(int num: numbers){
            System.out.println(num);
        }
    }

    /**
     * Method addCar
     *
     * @param toAdd A parameter of type Car to add to the arrayList
     */
    public void addCar(Car toAdd){
        if(toAdd != null){
            carLot.add(toAdd);   
        }
    }

    /**
     * Method getCar
     *
     * @param index A parameter 
     */
    public void getCar(int index){
        if(index >= 0 && index < carLot.size()){
            Car c = carLot.get(index)   ;
            c.displayDetails();
        } else{
            System.out.println("invalid index was provided");
        }
    }

    /**
     * Method sellCar(remove)
     *
     * @param index A parameter
     */
    public void sellCar(int index){
        if(index >= 0 && index < carLot.size()){
            carLot.remove(index) ;
        }else{
            System.out.println("invalid index was provided");
        }
    }

    /**
     * Method amountOfCars
     *
     * @return The return value is the size of the arrayList
     */

    public int amountOfCars(){
        return carLot.size();
    }

    /**
     * Method displayCarDetails
     *
     */
    public void displayCarDetails(){
        for(Car c:carLot)   {
            c.displayDetails();  
        }
    }

    /**
     * Method findCar
     *
     * @param brand A parameter to search in the collection
     */

    public void findCar(String brand){
        for(Car oneCar: carLot){
            String brandName = oneCar.getCarBrand();
            if(brandName.equalsIgnoreCase(brand)){
                oneCar.displayDetails();  
            }
        }
    }

    
    public static void main(String[] args){
        ArrayListDemo demo = new ArrayListDemo();
        Car c1 = new Car("Honda",2015);
        Car c2 = new Car("Toyota",2018);
        Car c3 = new Car("Ford",2000);
        demo.addCar(c1);
        demo.addCar(c2);
        demo.addCar(c3);
        demo.displayCarDetails();
        System.out.println(" calling method getCar with invalid index :");
        demo.getCar(-1);
        System.out.println(" calling method getCar with valid index : ");
        demo.getCar(1);
        demo.sellCar(2);
        System.out.println(" the car list after removing the car Ford");
        demo.displayCarDetails();
        System.out.println(" the number of cars in the collection is "
            + demo.amountOfCars());
        System.out.println(" calling method findCar on the parameter Honda")   ;
        demo.findCar("Honda");                           

    }

}
