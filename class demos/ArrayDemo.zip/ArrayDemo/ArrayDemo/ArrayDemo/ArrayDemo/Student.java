
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student
{
    // instance variables - replace the example below with your own
    private String name;

    /**
     * Constructor for objects of class Student
     */
    public Student(String name)
    {
       this.name = name;
    }

   public String getName(){
       return name;
    }
}
