public class Dog {
    private String name;
    private String breed;
    private int ageInYears;
    private double weightInPounds;
    private boolean isPuebred;
    private char gender;
}
