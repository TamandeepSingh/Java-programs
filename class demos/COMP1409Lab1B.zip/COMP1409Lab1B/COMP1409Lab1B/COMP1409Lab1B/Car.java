

public class Car
{
    private String make;
    private String model;
    private int yearOfMake;
    private boolean isManualTransmission;
}
