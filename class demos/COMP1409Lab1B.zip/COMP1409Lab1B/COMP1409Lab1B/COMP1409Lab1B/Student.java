

public class Student
{
    private String firstName;
    private String lastName;
    private char middleInitial;
    private int ageInYear;
    private boolean isFullTime;
    private char gender;
}
