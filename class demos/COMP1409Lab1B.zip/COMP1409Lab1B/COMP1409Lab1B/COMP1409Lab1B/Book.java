

public class Book
{
    private int heightInCm;
    private int widthInCm;
    private String title;
    private String author;
    private boolean isAudioBook;
}
