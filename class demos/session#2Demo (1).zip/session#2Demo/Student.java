// single line comment 

/*
 * multi
 * line
 * comment
 * 
 * 
 * 
 */






/**
 *  session#2 Demo
 *  @author Rana
 *  @version 2019/9/14
 */

public class Student
{// instance variables
    
    
   
   private String name;
   private int ageInYears;
   private boolean isFulltimeStudent;
   private int courseMark;
    
    // constuctors
    /**
     * no-args constructor
     */
    public Student(){
        name = "Bob";
        ageInYears = 30;
        isFulltimeStudent = true;
        
    }
    /**
     * Student constructor
     * @param inputName to set name
     * @param inputAge to set ageInYears
     * @param fulltime to set isFullTimeStudent
     * @param mark to set courseMark
     */
    public Student(String inputName , int inputAge , boolean fulltime, int mark ){
        if(inputName != null){
            name = inputName;
        } else{
            throw new IllegalArgumentException("name cannot be null");
        }
        
        // if(inputAge <= 0){
             // throw new IllegalArgumentException("age cannot be 0 or less than 0");
        // } else{
           // ageInYears = inputAge;   
        // }
        
        if(inputAge > 0){
          ageInYears = inputAge;   
        }
        
        isFulltimeStudent = fulltime;
        
        if(mark >= 0){
            if(mark <= 100){
                 courseMark = mark;
            } else{
                throw new IllegalArgumentException("mark cannot be  morethan 100");
            }
        } else{
            throw new IllegalArgumentException("mark cannot be  less than 0");
        }
        
    }
    
    
    
    // methods
    /**
     * method getLetterGrade
     * @return char the letter grade of the student
     */
      public char getLetterGrade(){
        if(courseMark >= 80){
           return'A';   
        }else if(courseMark >= 70){
            return 'B';
        } else if(courseMark >= 50){
            return 'C';
        } else{
            return 'F';
        }
    }
   
    
}